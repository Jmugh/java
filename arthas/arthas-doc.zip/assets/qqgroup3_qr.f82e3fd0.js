const s="/images/dingding_qr.jpg",g="/images/dingding2_qr.jpg",i="/images/dingding3_qr.jpg",_="/images/qqgroup_qr.jpg",o="/images/qqgroup3_qr.jpg";export{s as _,g as a,i as b,_ as c,o as d};
