const t="/images/arthas-output-recording.png";export{t as _};
