const s="/images/arthas-output.jpg",t="/images/arthas-output-svg.jpg";export{s as _,t as a};
